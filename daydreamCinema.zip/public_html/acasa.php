<?php
require_once('header.php');
?>
<!doctype html>
<html lang = "ro">
  <head>
  <meta charset = "UTF-8"/>
  <title>Daydream Cinema</title>
  <link rel="stylesheet" type="text/css" href="css/back.css" />
  </head>

<body\>

<h1><span style="color:#d9d8d6">DAY</span>DREAM</h1>
<h2>CINEMA</h2>
</body>
</html>