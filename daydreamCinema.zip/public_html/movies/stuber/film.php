<?php
include_once '../../header2.php';
?>
<!doctype html>
<html lang = "ro">
  <head>
  <meta charset = "UTF-8"/>
  <title>Stuber: Detectiv de nevoie</title> 
  <link rel="stylesheet" type="text/css" href="../../css/scroll.css" />
  <link rel="stylesheet" type="text/css" href="b.css" />
  </head>

<body>


<h1>Stuber: Detectiv de nevoie</h1>
<div class="container">
<div class="imag">
<img src="poster.jpg">
</div>
<div class="text">
<h3>Descriere:</h3>
<p>Când Stu (Kumail Nanjiani), un blând șofer de Uber, ia un pasager (Dave Bautista) care se dovedește a fi un polițist aflat pe urmele unui criminal brutal, Stu este aruncat într-un coșmar în care încearcă disperat să nu-și piardă mințile, viața și rating-ul de cinci stele.</p>
<h3>Genuri:</h3>
<p>Acţiune, Comedie</p>
<h3>Preț bilet adult: 15 lei</h3>
<h3>Preț bilet copil: 12 lei</h3>
<h3>Trailer:</h3>
<iframe width="620" height="370" src="https://youtube.com/embed/GOogDuAkrYY">
</iframe>
</div>
</div>
<table>
<tr>
<th><img class="actori" src="1.jpg" alt="Avatar1" height="90px" width="90px">
</th>
<th>
<img class="actori" src="2.jpg" alt="Avatar2">
</th>
<th>
<img class="actori" src="3.jpg" alt="Avatar3" height="90px" width="90px">
</th>
</tr>
<tr>
<td>Dave Batista ca Detective Vic</td>
<td>Kumail Nanjiani ca Stu</td>
<td>Natalie Morales ca Nicole</td>
</tr>
</table>
<p> </p>
<p> </p>
</body>
</html>