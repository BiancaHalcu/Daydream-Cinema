<?php
include_once '../../header2.php';
?>
<!doctype html>
<html lang = "ro">
  <head>
  <meta charset = "UTF-8"/>
  <title>Raya și ultimul dragon</title> 
  <link rel="stylesheet" type="text/css" href="../../css/scroll.css" />
  <link rel="stylesheet" type="text/css" href="b.css" />
  </head>

<body>

<h1>Raya și ultimul dragon</h1>
<div class="container">
<div class="imag">
<img src="poster.jpg">
</div>
<div class="text">
<h3>Descriere:</h3>
<p> În Lumandra, tărâm aflat pe un Pământ redesenat, populat de o civilizație antică, războinica Raya este hotărâtă să găsească ultimul dragon în viață.</p>
<h3>Genuri:</h3>
<p>Acțiune, Aventură, Animaţie</p>
<h3>Preț bilet adult: 10 lei</h3>
<h3>Preț bilet copil: 15 lei</h3>
<h3>Trailer:</h3>
<iframe width="620" height="370" src="https://youtube.com/embed/1VIZ89FEjYI">
</iframe>
</div>
</div>
<p> </p>
<p> </p>
</body>
</html>