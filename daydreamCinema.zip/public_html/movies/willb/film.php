<?php
include_once '../../header2.php';
?>
<!doctype html>
<html lang = "ro">
  <head>
  <meta charset = "UTF-8"/>
  <title>Familia Willoughby</title> 
  <link rel="stylesheet" type="text/css" href="../../css/scroll.css" />
  <link rel="stylesheet" type="text/css" href="b.css" />
  </head>

<body>


<h1>Familia Willoughby</h1>
<div class="container">
<div class="imag">
<img src="poster.jpg">
</div>
<div class="text">
<h3>Descriere:</h3>
<p> Convinși că se vor descurca mai bine crescând singuri, copiii familiei Willoughby pun la cale un plan viclean pentru a-și trimite părinții egoiști într-o vacanță. Apoi, frații pornesc în propria lor aventură pentru a afla ce înseamnă cu adevărat familia.</p>
<h3>Genuri:</h3>
<p>Animație, Familie, Comedie</p>
<h3>Preț bilet adult: 10 lei</h3>
<h3>Preț bilet copil: 15 lei</h3>
<h3>Trailer:</h3>
<iframe width="620" height="370" src="https://youtube.com/embed/VipTKIBmZSA">
</iframe>
</div>
</div>
<p> </p>
<p> </p>
</body>
</html>