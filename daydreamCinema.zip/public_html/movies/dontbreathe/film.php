<?php
include_once '../../header2.php';
?>
<!doctype html>
<html lang = "ro">
  <head>
  <meta charset = "UTF-8"/>
  <title>Omul din întuneric</title> 
  <link rel="stylesheet" type="text/css" href="../../css/scroll.css" />
  <link rel="stylesheet" type="text/css" href="b.css" />
  </head>

<body>


<h1>Omul din întuneric</h1>
<div class="container">
<div class="imag">
<img src="poster.jpg">
</div>
<div class="text">
<h3>Descriere:</h3>
<p>Un grup de tineri intră prin efracție în casa unui om orb, crezând că vor scăpa cu crima perfectă, însă se înșeală.</p>
<h3>Genuri:</h3>
<p>Horror, Thriller</p>
<h3>Preț bilet: 15 lei</h3>
<h3>Trailer:</h3>
<iframe width="620" height="370" src="https://youtube.com/embed/76yBTNDB6vU">
</iframe>
</div>
</div>
<table>
<tr>
<th><img class="actori" src="1.jpg" alt="Avatar1" height="90px" width="90px">
</th>
<th>
<img class="actori" src="2.jpg" alt="Avatar2">
</th>
<th>
<img class="actori" src="3.jpg" alt="Avatar3" height="90px" width="90px">
</th>
</tr>
<tr>
<td>Stephen Lang ca Bărbatul orb</td>
<td>Jane Levy ca Rocky</td>
<td>Dylan Minnette ca Alex</td>
</tr>
</table>
<p> </p>
<p> </p>
</body>
</html>