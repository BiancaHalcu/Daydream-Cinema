<?php
include_once '../../header2.php';
?>
<!doctype html>
<html lang = "ro">
  <head>
  <meta charset = "UTF-8"/>
  <title>Regatul de Gheață 2</title> 
  <link rel="stylesheet" type="text/css" href="../../css/scroll.css" />
  <link rel="stylesheet" type="text/css" href="b.css" />
  </head>

<body>

<h1>Regatul de Gheață 2</h1>
<div class="container">
<div class="imag">
<img src="poster.jpg">
</div>
<div class="text">
<h3>Descriere:</h3>
<p> De ce s-a născut Elsa cu puteri magice? Adevărul despre trecut o așteaptă într-o călătorie în necunoscut — spre pădurile fermecate și mările sumbre de dincolo de Arendelle. Răspunsurile o atrag, dar ele îi și amenință regatul. Împreună cu Anna, Kristoff, Olaf și Sven, ea va avea de înfruntat o călătorie periculoasă, dar uluitoare. În ”Regatul de gheață”, Elsa se temea că puterile ei sunt prea mari pentru lume. În ”Regatul de gheață 2”, ea speră că vor fi de ajuns.</p>
<h3>Genuri:</h3>
<p>Animație, Aventură</p>
<h3>Preț bilet adult: 10 lei</h3>
<h3>Preț bilet copil: 15 lei</h3>
<h3>Trailer:</h3>
<iframe width="620" height="370" src="https://youtube.com/embed/Zi4LMpSDccc">
</iframe>
</div>
</div>
<p> </p>
<p> </p>
</body>
</html>