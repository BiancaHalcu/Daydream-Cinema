<?php
include_once '../../header2.php';
?>
<!doctype html>
<html lang = "ro">
  <head>
  <meta charset = "UTF-8"/>
  <title>#Alive</title> 
  <link rel="stylesheet" type="text/css" href="../../css/scroll.css" />
  <link rel="stylesheet" type="text/css" href="alive.css" />
  </head>

<body>


<h1>#ÎnViață (2020)</h1>
<div class="container">
<div class="imag">
<img src="alive.jpg">
</div>
<div class="text">
<h3>Descriere:</h3>
<p>Răspândirea rapidă a unei infecții necunoscute provoacă o pandemie și un adevărat haos total într-un oraș plin de zombi.</p><p>Un tânăr trebuie să încerce să supraviețuiască închis în apartamentul său în timp ce așteaptă ajutor.</p>
<h3>Genuri:</h3>
<p>Acţiune, Horror, Suspans</p>
<h3>Preț bilet adult: 15 lei</h3>
<h3>Preț bilet copil: 12 lei</h3>
<h3>Trailer:</h3>
<iframe width="620" height="370" src="https://youtube.com/embed/jQ8CCg1tOqc">
</iframe>
</div>
</div>
<table>
<tr>
<th><img class="actori" src="aiy.jpg" alt="Avatar1">
</th>
<th>
<img class="act" src="psh.jpg" alt="Avatar2">
</th>
<th>
<img class="actori" src="bsj.jpg" alt="Avatar3">
</th>
</tr>
<tr>
<td>Ah-In Yoo ca Oh Joon-woo</td>
<td>Shin-Hye Park ca Kim Yoo-bin</td>
<td>Bae-Soo Jeon ca omul mascat</td>
</tr>
</table>
<p> </p>
<p> </p>
</body>
</html>