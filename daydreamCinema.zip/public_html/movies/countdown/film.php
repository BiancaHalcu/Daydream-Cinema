<?php
include_once '../../header2.php';
?>
<!doctype html>
<html lang = "ro">
  <head>
  <meta charset = "UTF-8"/>
  <title>O aplicaţie de coşmar</title> 
  <link rel="stylesheet" type="text/css" href="../../css/scroll.css" />
  <link rel="stylesheet" type="text/css" href="b.css" />
  </head>

<body>

<h1>O aplicaţie de coşmar</h1>
<div class="container">
<div class="imag">
<img src="poster.jpg">
</div>
<div class="text">
<h3>Descriere:</h3>
<p>O aplicație de telefon care arată când va muri persoana care o accesează se transformă dintr-o virală amuzantă într-o reală amenințare. Același lucru i se întâmplă unei asistente medicale care află că mai are de trăit 3 zile și trebuie să lupte cu timpul, dar și împotriva unei creaturi malefice aflate pe urmele ei.</p>
<h3>Genuri:</h3>
<p>Horror, Thriller</p>
<h3>Preț bilet: 15 lei</h3>
<h3>Trailer:</h3>
<iframe width="620" height="370" src="https://youtube.com/embed/TZsgNH17_X4">
</iframe>
</div>
</div>
<table>
<tr>
<th><img class="actori" src="1.jpg" alt="Avatar1" height="90px" width="90px">
</th>
<th>
<img class="actori" src="2.jpg" alt="Avatar2">
</th>
<th>
<img class="actori" src="3.jpg" alt="Avatar3" height="90px" width="90px">
</th>
</tr>
<tr>
<td>Elizabeth Lail ca Quinn Harris</td>
<td>Jordan Calloway ca Matt Monroe</td>
<td>Peter Facinelli ca Dr. Sullivan</td>
</tr>
</table>
<p> </p>
<p> </p>
</body>
</html>