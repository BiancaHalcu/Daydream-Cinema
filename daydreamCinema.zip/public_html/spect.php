<?php
require_once('header.php');
?>
<!doctype html>
<html lang = "ro">
  <head>
  <meta charset = "UTF-8"/>
  <title>Spectacole</title>
  <link rel="stylesheet" type="text/css" href="../css/scroll.css" />
  <link rel="stylesheet" type="text/css" href="../css/spect.css" />
  </head>

<body>

<h1>Spectacole</h1>
<center>
<table>
<tr><td><h3>Cea mai frumoasă zi</h3>
<p>de Slavomir Mrozek</p></td>
<td><p>Regia: Ofelia Popii</p>
<p>Distribuția:</p>
<p>Adrian Matioc</p>
<p>Ciprian Scurte</p></td>
<td><p>Luni: 10:00-11:25</p>
<p>Duminică: 12:00-13:25</p></td>
<td><p>Preț: 20 lei </p></td>
</tr>
<tr><td><h3>Divorț în ziua nunții</h3>
<td><p>Regia: Cătălin Stelian</p>
<p>Distribuția:</p>
<p>Cristina Diaconescu</p>
<p>Emanuel Bighe</p></td>
<td><p>Joi: 13:00-14:10</p>
<p>Sambată: 14:00-15:10</p></td>
<td><p>Preț: 25 lei </p></td>
</tr>
<tr><td><h3>Anonimul venețian</h3>
<td><p>Regia: Ion Caramitru</p>
<p>Distribuția:</p>
<p>Ilinca Goia</p>
<p>Ioan Andrei Ionescu</p></td>
<td><p>Luni: 14:00-15:30</p>
<p>Vineri: 11:00-12:30</p></td>
<td><p>Preț: 20 lei </p></td>
</tr>
<tr><td><h3>Frumoasa călătorie a urșilor</h3><h3>panda povestită de un saxofonist</h3><h3>care avea o iubită la Frankfurt</h3>
<td><p>Regia: Cătălina Buzoianu</p>
<p>Distribuția:</p>
<p>Iolanda Covaci</p>
<p>Marius Călugărița</p></td>
<td><p>Miercuri: 10:00-11:15</p>
<p>Duminică: 11:00-12:15</p></td>
<td><p>Preț: 20 lei </p></td>
</tr>
</table>
</center>
</body>
</html>